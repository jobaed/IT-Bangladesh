-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2022 at 12:46 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `contest`
--

CREATE TABLE `contest` (
  `id` int(250) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `institute` text NOT NULL,
  `semester` varchar(15) NOT NULL,
  `roll` int(10) NOT NULL,
  `headOfTheDept` varchar(100) NOT NULL,
  `district` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contest`
--

INSERT INTO `contest` (`id`, `name`, `email`, `phone`, `institute`, `semester`, `roll`, `headOfTheDept`, `district`) VALUES
(1, 'Jobaed Bhuiyan', 'jobaedbhuiyan34@gmail.com', '01304588419', 'brahmanbaria polytechnic institute', '8th-semester', 936840, 'Mohammod Selim', 'Kishoreganj'),
(2, 'Ali Arafat', 'ali@gmail.com', '0000000000', 'Brahmanbaria polytechnic institute', '8th-semester', 936840, 'Mohammod Selim', 'Kishoreganj'),
(3, 'Ali Arafat', 'ali@gmail.com', '0000000000', 'Brahmanbaria polytechnic institute', '8th-semester', 936840, 'Mohammod Selim', 'Kishoreganj'),
(4, 'Arifur Rahman Arif', 'arif@gmail.com', '0000000000', 'Brahmanbaria polytechnic institute', '8th-semester', 936817, 'Mohammod Selim', 'Comilla'),
(5, 'Mr Mango', 'mango@gmail.com', '0170758677', 'Brahmanbaria polytechnic institute', '8th-semester', 936840, 'Mohammod Selim', 'Comilla'),
(6, 'Mr Mango', 'mango@gmail.com', '0170758677', 'Brahmanbaria polytechnic institute', '8th-semester', 936840, 'Mohammod Selim', 'Comilla'),
(7, 'Mahmudul Hasan', 'kissm1092@gmail.com', '00000000', 'Brahmanbaria polytechnic institute', '8th-semester', 375692, 'Mohammod Selim', 'Narsingdi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contest`
--
ALTER TABLE `contest`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contest`
--
ALTER TABLE `contest`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
